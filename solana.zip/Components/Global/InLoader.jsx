import React from "react";

const InLoader = () => {
  return (
    <div class="new_loader">
      <div class="new_bar1"></div>
      <div class="new_bar2"></div>
      <div class="new_bar3"></div>
      <div class="new_bar4"></div>
      <div class="new_bar5"></div>
      <div class="new_bar6"></div>
      <div class="new_bar7"></div>
      <div class="new_bar8"></div>
      <div class="new_bar9"></div>
      <div class="new_bar10"></div>
      <div class="new_bar11"></div>
      <div class="new_bar12"></div>
    </div>
  );
};

export default InLoader;
